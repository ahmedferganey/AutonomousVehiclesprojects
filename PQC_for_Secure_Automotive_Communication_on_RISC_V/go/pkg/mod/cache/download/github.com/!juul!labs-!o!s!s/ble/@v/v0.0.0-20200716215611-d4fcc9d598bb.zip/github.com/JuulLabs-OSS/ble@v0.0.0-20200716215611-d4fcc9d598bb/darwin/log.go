package darwin

import (
	"github.com/mgutz/logxi/v1"
)

var logger = log.New("darwin")
