# Case 06

When `Options.Skip` is provided and returns `true`, src files should be skipped.