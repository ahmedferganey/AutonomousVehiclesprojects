Install
-------

.. toctree::
   :maxdepth: 2

   install_mac
   install_linux
   install_windows
   prev_releases
